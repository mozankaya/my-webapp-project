package servlet;

import com.google.gson.Gson;
import dao.TaskDAO;
import model.Task;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class TasksServlet extends HttpServlet {
    private TaskDAO taskDAO;
    private Gson gson;

    @Override
    public void init() throws ServletException {
        taskDAO = new TaskDAO();
        gson = new Gson();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        String pathInfo = req.getPathInfo();
        PrintWriter out = resp.getWriter();
        if (pathInfo == null || "/".equals(pathInfo)) {
            List<Task> tasks = taskDAO.getAllTasks();
            out.print(gson.toJson(tasks));
        } else {
            try {
                int id = Integer.parseInt(pathInfo.substring(1));
                Task task = taskDAO.getTaskById(id);
                if (task != null) {
                    out.print(gson.toJson(task));
                } else {
                    resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                }
            } catch (NumberFormatException e) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            }
        }
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        BufferedReader reader = req.getReader();
        StringBuilder body = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            body.append(line);
        }
        Task task;
        try {
            task = gson.fromJson(body.toString(), Task.class);
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().print("invalid json");
            return;
        }
        if (task == null || task.getTitle() == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().print("missing title");
            return;
        }
        boolean success = taskDAO.addTask(task);
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        if (success) {
            resp.setStatus(HttpServletResponse.SC_CREATED);
            out.print(gson.toJson(task));
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\":\"addTask returned false\"}");
        }
        out.flush();
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        try {
            int id = Integer.parseInt(pathInfo.substring(1));
            BufferedReader reader = req.getReader();
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line);
            }
            System.out.println("[DEBUG] PUT body: " + body.toString());
            Task task;
            try {
                task = gson.fromJson(body.toString(), Task.class);
            } catch (Exception e) {
                System.out.println("[ERROR] could not parse JSON in PUT: " + e.getMessage());
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                resp.getWriter().print("invalid json");
                return;
            }
            if (task == null || task.getTitle() == null) {
                System.out.println("[ERROR] parsed PUT task is null or missing title");
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                resp.getWriter().print("missing title");
                return;
            }
            task.setId(id);
            boolean success = taskDAO.updateTask(task);
            resp.setContentType("application/json");
            PrintWriter out = resp.getWriter();
            if (success) {
                out.print(gson.toJson(task));
            } else {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            }
            out.flush();
        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        try {
            int id = Integer.parseInt(pathInfo.substring(1));
            boolean success = taskDAO.deleteTask(id);
            if (success) {
                resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
            } else {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }
}
